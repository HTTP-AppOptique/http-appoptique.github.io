# Ray Optics Sample Files

Open one `json` file below and Right-Click the `Raw` button and save the file.

1. [Spherical lens and mirror/球面透鏡與面鏡/球面透镜与面镜](spherical-lens-and-mirror.json)
2. [Compound microscope/複式顯微鏡/复式显微镜](compound-microscope.json)
3. [Reflection and refraction of a single ray/單一光線的反射與折射/单一光线的反射与折射](reflection-and-refraction-of-a-single-ray.json)
4. [Images formed by two mirrors/兩面鏡子成像/两面镜子成像](images-formed-by-two-mirrors.json)
5. [Apparent depth of an object under water/水中物體的視深度/水中物体的视深度](apparent-depth-of-an-object-under-water.json)